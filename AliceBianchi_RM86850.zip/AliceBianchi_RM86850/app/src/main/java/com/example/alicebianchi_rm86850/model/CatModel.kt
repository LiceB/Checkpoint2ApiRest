package com.example.alicebianchi_rm86850.model

data class CatModel(
    val breeds: List<BreedModel>,
    val height: Int,
    val id: String,
    val url: String,
    val width: Int
)