package com.example.alicebianchi_rm86850.model

data class WeightModel(
    val imperial: String,
    val metric: String
)